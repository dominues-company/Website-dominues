<template>
  <section class="waiting-room-section">
    <div v-if="!showGame" class="waiting-room-wrapper">
      <div class="waiting-room-card">
        <h5>Sala de Espera - {{ localTable?.name || `Mesa ${localTable?.id}` }}</h5>

        <!-- Jugadores actuales -->
        <p>
          <strong>Jugadores actuales:</strong> {{ localPlayers.length }}/{{ localTable?.max_number_players || 4 }}
        </p>

        <!-- Rango permitido -->
        <p class="text-muted small">
          Jugadores permitidos: {{ localTable?.min_number_players || 2 }}–{{ localTable?.max_number_players || 4 }}
        </p>

        <!-- Lista de usuarios -->
        <div class="users-list">
          <div
            v-for="user in localPlayers"
            :key="user.id"
            class="user-item"
          >
            <i class="fas fa-user"></i> {{ user.name || user.email }}
          </div>

          <div
            v-for="n in ((localTable?.max_number_players || 4) - localPlayers.length)"
            :key="'empty-' + n"
            class="user-item empty"
          >
            <i class="fas fa-user"></i> Vacante
          </div>
        </div>

        <!-- Tiempo de espera -->
        <p v-if="localPlayers.length >= (localTable?.min_number_players || 2)">
          <strong>Tiempo restante para iniciar:</strong> {{ waitingTime }} segundos
        </p>

        <!-- Estado de espera -->
        <div v-else class="status">
          <p><em>Esperando que otro jugador se una...</em></p>
        </div>

        <button class="leave-button" @click="leaveRoom">Salir de la sala</button>
      </div>
    </div>

    <div v-else class="game-container">
      <iframe
        ref="gameIframe"
        src="/domino/index.html"
        width="100%"
        height="700"
        frameborder="0"
        @load="onGameLoad"
      ></iframe>
    </div>
  </section>
</template>

<script>
import api from '@/services/api';

export default {
  name: 'WaitingRoomMultiplayer',
  props: {
    table: { type: Object, required: true },
    user: { type: Object, required: true },
    waitingTimeLeft: { type: Number, required: true }
  },
  data() {
    return {
      localPlayers: [],
      showGame: false,
      localTable: { ...this.table },
      pollingInterval: null,
      waitingInterval: null,
      waitingTime: this.waitingTimeLeft
    };
  },
  mounted() {
    this.joinRoom();
    this.startPolling();
  },
  beforeUnmount() {
    this.stopPolling();
    if (this.waitingInterval) clearInterval(this.waitingInterval);
  },
  computed: {
    tableId() {
      return this.table?.id || this.localTable?.id;
    }
  },
  watch: {
    'localPlayers.length'(newVal) {
      const min = this.localTable?.min_number_players || 2;
      if (newVal >= min && !this.waitingInterval && !this.showGame) {
        this.tryStartSession();
      }
    },
    waitingTime(newVal) {
      if (newVal <= 0 && this.localPlayers.length >= (this.localTable?.min_number_players || 2) && !this.showGame) {
        this.startGame();
      }
    }
  },
  methods: {
    async joinRoom() {
      try {
        const res = await api.post(`/api/tables/${this.tableId}/join`);
        if (res.data?.room?.users) {
          this.localPlayers = res.data.room.users;
        }
        if (res.data?.room) {
          this.localTable = res.data.room;
          this.listenForSessionStart();
        }
      } catch (err) {
        console.error('Error al unirse a la sala:', err);
      }
    },

    startPolling() {
      this.pollingInterval = setInterval(async () => {
        try {
          const res = await api.get(`/api/tables/${this.tableId}`);
          if (res.data?.table) {
            this.localTable = res.data.table;
          }
          if (res.data?.users) {
            this.localPlayers = res.data.users;
          }
          if (res.data?.table?.session_started) {
            clearInterval(this.pollingInterval);
            this.goToGame();
          }
        } catch (err) {
          console.error('Error en el polling:', err);
        }
      }, 3000);
    },

    stopPolling() {
      if (this.pollingInterval) {
        clearInterval(this.pollingInterval);
        this.pollingInterval = null;
      }
    },

    listenForSessionStart() {
      if (!this.tableId) return;

      console.log(`[SOCKET] 🎧 Suscrito a table.${this.tableId}`);

      window.Echo.channel(`table.${this.tableId}`)
        .listen('SessionStarted', (event) => {
          console.log(`[SOCKET] ✅ Evento SessionStarted recibido en mesa ${this.tableId}`, event);
          this.stopPolling();
          this.showGame = true;
        })
        .listen('ReadyToPlay', (event) => {
          console.log(`[SOCKET] 🟢 Evento ReadyToPlay recibido en mesa ${this.tableId}:`, event);

          // Puedes guardar los IDs de los usuarios listos si quieres
          if (!this.readyPlayers) this.readyPlayers = [];
          if (!this.readyPlayers.includes(event.userId)) {
            this.readyPlayers.push(event.userId);
          }

          // Acción opcional: Si todos están listos, lanzar juego automáticamente
          const expected = this.localPlayers.length;
          if (this.readyPlayers.length === expected) {
            console.log('✅ Todos los jugadores están listos. Iniciando...');
            this.startGame(); // O cualquier otro método de inicio
          }
        });
    },

    goToGame() {
      this.$router.push({
        name: 'GameMultiplayer',
        params: { tableId: this.tableId },
      });
    },

    async leaveRoom() {
      try {
        await api.post(`/api/tables/${this.tableId}/leave`);
        this.$emit('leave');
        this.$router.push('/dashboard');
      } catch (error) {
        console.error('Error al salir de la sala:', error);
        alert('No se pudo salir de la sala.');
      }
    },

    startGame() {
      this.stopPolling();
      this.showGame = true;

      // 🟢 Notifica al backend que este jugador está listo
      this.sendReadyToPlayToBackend();

      // 🎮 Envía los datos al iframe del juego
      this.sendDataToGame();
    },

    onGameLoad() {
      setTimeout(() => {
        console.log('[IFRAME] 🎮 Juego cargado, enviando GAME_INIT');
        this.sendDataToGame();
        this.sendReadyToPlayToBackend();
      }, 500);
    },

    sendDataToGame() {
      const iframe = this.$refs.gameIframe;
      if (!iframe || !iframe.contentWindow) return;

      const playerNames = this.localPlayers.map(p => p.name || p.email);
      const playerIds = this.localPlayers.map(p => p.id);

      const dataToSend = {
        type: 'GAME_INIT',
        data: {
          players: playerNames.length,
          names: playerNames,
          userIds: playerIds,
          mesa: `Mesa ${this.tableId}`,
          mesaId: this.tableId,
          apuesta: this.localTable?.entry_price || 0,
          userId: this.user?.id,
          balance: this.user?.balance || 0,
          mode: this.localTable?.mode?.name || 'Multiplayer',
          multiplayer: true,
          socketData: {
            userId: this.user?.id,
            mesaId: this.tableId,
            online: true,
            userIds: playerIds
          }
        }
      };

      console.log('[VUE] 📤 Enviando GAME_INIT al iframe:', dataToSend);

      iframe.contentWindow.postMessage(dataToSend, '*');
    },

    async sendReadyToPlayToBackend() {
      try {
        const res = await api.post(`/api/tables/${this.tableId}/ready`);
        console.log('🟢 READY_TO_PLAY enviado al backend:', res.data);
      } catch (err) {
        console.error('🔴 Error al enviar READY_TO_PLAY:', err.response?.data || err.message);
      }
    },

    async tryStartSession() {
      try {
        const res = await api.post(`/api/tables/${this.tableId}/start-session`);
        if (res.data?.start_time) {
          this.localTable.start_time = res.data.start_time;
          this.startCountdownFromTime(this.localTable.start_time);
        }
      } catch (err) {
        if (err.response && err.response.status === 409 && err.response.data?.start_time) {
          this.localTable.start_time = err.response.data.start_time;
          this.startCountdownFromTime(this.localTable.start_time);
        } else {
          console.error('Error al iniciar sesión:', err);
        }
      }
    },

    startCountdownFromTime(startTimeString) {
      const startTime = new Date(startTimeString).getTime();
      const now = Date.now();
      const timeLeft = Math.max(Math.floor((startTime + 20000 - now) / 1000), 0);

      this.waitingTime = timeLeft;

      this.waitingInterval = setInterval(() => {
        this.waitingTime--;
        if (this.waitingTime <= 0) {
          clearInterval(this.waitingInterval);
          this.waitingInterval = null;
          if (!this.showGame) this.startGame();
        }
      }, 1000);
    },
  }
};
</script>

<style scoped>
.waiting-room-section {
  width: 100%;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px 16px;
  background: transparent;
  box-sizing: border-box;
}
.waiting-room-wrapper {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
}
.waiting-room-card {
  background: #222;
  color: #fff;
  padding: 32px 24px;
  border-radius: 12px;
  min-width: 320px;
  max-width: 400px;
  box-shadow: 0 4px 24px rgba(0,0,0,0.15);
  text-align: center;
  margin: auto;
}
.users-list {
  display: flex;
  justify-content: center;
  margin: 16px 0;
  flex-wrap: wrap;
}
.user-item {
  background: #444;
  color: #fff;
  border-radius: 6px;
  padding: 8px 12px;
  margin: 4px;
  display: flex;
  align-items: center;
  font-size: 14px;
}
.user-item.empty {
  background: #666;
  color: #bbb;
}
.status {
  margin-top: 1rem;
  font-style: italic;
  color: #ccc;
}
.leave-button {
  margin-top: 2rem;
  padding: 0.5rem 1rem;
  background-color: #d33;
  color: white;
  border: none;
  cursor: pointer;
  border-radius: 4px;
}
</style>
