<template>
  <div>
    <WaitingRoom
      v-if="table"
      :table="table"
      :waitingTimeLeft="waitingTimeLeft"
      :user="currentUser"
      @leave="handleLeave"
      @start-cpu="iniciarConCPU"
    />
    <div v-else class="loading">Cargando sala de espera...</div>
  </div>
</template>

<script>
import WaitingRoom from './WaitingRoom.vue';
import api from '@/services/api';
import { mapGetters } from 'vuex';

export default {
  name: 'WaitingRoomPage',
  components: { WaitingRoom },
  props: {
    tableId: { type: [String, Number], required: true }
  },
  data() {
    return {
      table: null,
      waitingTimeLeft: 20,
      waitingTimer: null
    }
  },
  computed: {
    ...mapGetters('auth', ['currentUser'])
  },
  async created() {
    await this.fetchTable();
    this.startWaitingTimer();
  },
  beforeUnmount() {
    this.stopWaitingTimer();
  },
  methods: {
    async fetchTable() {
      try {
        const response = await api.get(`/api/tables`);
        const tables = Array.isArray(response.data) ? response.data : response.data.data || [];
        this.table = tables.find(t => t.id == this.tableId);
      } catch (error) {
        this.table = null;
      }
    },
    startWaitingTimer() {
      this.waitingTimeLeft = 20;
      if (this.waitingTimer) clearInterval(this.waitingTimer);
      this.waitingTimer = setInterval(() => {
        this.waitingTimeLeft--;
        if (this.waitingTimeLeft <= 0) {
          clearInterval(this.waitingTimer);
          this.waitingTimer = null;
        }
      }, 1000);
    },
    stopWaitingTimer() {
      if (this.waitingTimer) clearInterval(this.waitingTimer);
      this.waitingTimer = null;
    },
    handleLeave() {
      this.$router.push('/dashboard');
    },
    iniciarConCPU() {
      alert('¡La partida se iniciará con jugadores CPU!');
      // Aquí puedes llamar a un endpoint para iniciar con CPU
    }
  }
}
</script>

<style scoped>
.loading {
  color: #fff;
  text-align: center;
  margin-top: 100px;
  font-size: 20px;
}
</style> 