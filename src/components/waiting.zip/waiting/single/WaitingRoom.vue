<template>
  <section class="waiting-room-section">
    <div v-if="!showGame" class="waiting-room-card">
      <h5>Sala de Espera - {{ table.name || `Mesa ${table.id}` }}</h5>

      <!-- Jugadores actuales -->
      <p><strong>Jugadores actuales:</strong> {{ table.current_players }}/{{ table.max_number_players || 4 }}</p>
      
      <!-- Rango permitido -->
      <p class="text-muted small">
        Jugadores permitidos: {{ table.min_number_players || 2 }}–{{ table.max_number_players || 4 }}
      </p>

      <!-- Lista de usuarios -->
      <div class="users-list">
        <div v-for="user in table.users" :key="user.id" class="user-item">
          <i class="fas fa-user"></i> {{ user.name || user.email }}
        </div>
        <div
          v-for="n in ((table.max_number_players || 4) - table.current_players)"
          :key="'empty-' + n"
          class="user-item empty"
        >
          <i class="fas fa-user"></i> Vacante
        </div>
      </div>

      <!-- Tiempo de espera -->
      <p><strong>Tiempo restante para iniciar:</strong> {{ waitingTimeLeft }} segundos</p>

      <!-- Botones -->
      <button v-if="waitingTimeLeft <= 0" @click="startGame">Iniciar Juego</button>
      <button @click="leaveRoom">Salir de la sala</button>
    </div>

    <div v-else class="game-container">
      <div class="game-header">
        <h4>Juego en curso - Mesa {{ table.id }}</h4>
        <p>
          Apuesta: {{ table.entry_price }} | Jugadores: {{ table.current_players }}/{{ table.max_number_players || 4 }}
        </p>
      </div>
      <iframe 
        ref="gameIframe"
        src="/domino/index.html" 
        width="100%" 
        height="700" 
        frameborder="0"
        @load="onGameLoad"
      ></iframe>
    </div>

    <div v-if="resultPopup.show" class="popup-overlay">
      <div class="popup-content">
        <h2>{{ resultPopup.title || 'Resultado' }}</h2>
        <p>{{ resultPopup.message || 'Mensaje no disponible' }}</p>
        <p class="note">Serás redirigido al dashboard...</p>
      </div>
    </div>

  </section>
</template>

<script>
import api from '@/services/api';
import { mapActions } from 'vuex'

export default {
  name: 'WaitingRoom',
  props: {
    table: { type: Object, required: true },
    waitingTimeLeft: { type: Number, required: true },
    user: { type: Object, required: true }
  },
  data() {
    return {
      showGame: false,
      leaving: false,
      gameData: {
        userId: null,
        userName: '',
        userBalance: 0,
        tableId: null,
        betAmount: 50,
        players: [],
        mode: 'multiplayer'
      },
      resultPopup: {
        show: false,
        title: '',
        message: ''
      }
    }
  },
  watch: {
    waitingTimeLeft(newVal) {
      if (newVal <= 0 && !this.showGame && !this.leaving) {
        this.startGame();
      }
    }
  },
  mounted() {
    window.addEventListener('message', this.handleGameMessage);
  },
  beforeUnmount() {
    window.removeEventListener('message', this.handleGameMessage);
  },
  methods: {
    ...mapActions('auth', ['updateUserData']),

    async startGame() {
      this.showGame = true;
      this.prepareGameData();

      // 🔄 Refrescar el balance desde la API
      try {
        const response = await api.get('/api/user');
        if (response.data) {
          await this.updateUserData(response.data); // ← actualiza en Vuex
          this.$forceUpdate(); // fuerza re-render si se usa user como prop
        }
      } catch (error) {
        console.error('Error al actualizar el balance:', error);
      }
    },
    async leaveRoom() {
      this.leaving = true;
      try {
        await api.post(`/api/tables/${this.table.id}/leave`);

        // Limpia el estado local si estás usando Vuex (opcional)
        if (this.$store) {
          this.$store.commit('UPDATE_USER_DATA', {
            ...this.user,
            table_id: null
          });
        }

        // Emite el evento por si el padre necesita saberlo
        this.$emit('leave');

        // Redirige al dashboard
        this.$router.push('/dashboard');
      } catch (error) {
        console.error('Error al salir de la sala:', error);
        alert('Error al salir de la sala');
      }
    },
    prepareGameData() {
      this.gameData = {
        userId: this.user.id,
        userName: this.user.name || this.user.email,
        userBalance: this.user.balance || 0,
        tableId: this.table.id,
        betAmount:  this.table.entry_price || '20',
        players: this.table.users || [],
        mode: this.table.mode?.name || 'Desconocido'
      };
    },
    onGameLoad() {
      setTimeout(() => {
        this.sendDataToGame();
      }, 1000);
    },
    sendDataToGame() {
      const iframe = this.$refs.gameIframe;
      if (!iframe || !iframe.contentWindow) {
        console.warn('No se encontró el iframe o su contentWindow');
        return;
      }

      const base = this.gameData;
      const isCPU = (this.table.mode?.name || base.mode) === 'CPU';

      const playerNames = base.players.map(p => p.name);
      const playerIds = base.players.map(p => p.id);

      if (isCPU) {
        // Añadimos "LA BANCA" como segundo jugador ficticio
        playerNames.push('LA BANCA');
        playerIds.push(null); // Sin userId
      }

      console.log(base)

      const transformedData = {
        players: playerNames.length,
        names: playerNames,
        userIds: playerIds,
        draw: true,
        pointIndex: 0,
        themeIndex: 0,
        apuesta: base.betAmount,
        mesa: `Mesa ${base.tableId}`,
        mesaId: this.table.id,
        balance: base.userBalance,
        userId: base.userId,
        mode: this.table.mode?.name || base.mode || 'Desconocido'
      };

      console.log('[VUE] Enviando al iframe (transformado):', transformedData);

      iframe.contentWindow.postMessage({
        type: 'GAME_INIT',
        data: transformedData
      }, '*');
    },
    handleGameMessage(event) {
      if (event.origin !== window.location.origin) return;

      const { type, data } = event.data || {};

      switch (type) {
        case 'GAME_RESULT': {
          if (!data || typeof data !== 'object' || !('userId' in data) || !('result' in data)) {
            console.error('GAME_RESULT con datos inválidos:', data);
            return;
          }

          const isWinner = data.userId === this.user.id && data.result === 'gano';

          this.processGameResult({
            isWinner,
            gameData: data
          });
          break;
        }

        case 'GAME_ERROR':
          console.error('Error en el juego:', data);
          break;


      }
    },
    async processGameResult(result) {
      try {
        const apuesta = parseFloat(result.gameData.apuesta);
        const tableId = result.gameData.mesaId;

        const acum = 2;
        // const totalPot = apuesta * this.table.current_players;
        const totalPot = apuesta * acum;
        const houseFee = parseFloat((totalPot * 0.20).toFixed(2));
        const winnerAmount = parseFloat((totalPot - houseFee).toFixed(2));

        const gameResult = {
          userId: this.user.id,
          tableId,
          betAmount: winnerAmount,
          totalPot,
          houseFee,
          winnerAmount,
          isWinner: result.isWinner,
          gameData: result.gameData,
          timestamp: new Date().toISOString()
        };

        console.log("📤 Enviando resultado al backend:", gameResult);

        const response = await api.post(`/api/game/result`, gameResult);

        if (response.data.success) {
          // Mostrar popup para ambos casos
          this.resultPopup = {
            show: true,
            title: result.isWinner ? '🎉 ¡Felicidades!' : '😢 Lo sentimos',
            message: result.isWinner
              ? `Has ganado $${winnerAmount}!`
              : `No ganaste esta vez, pero puedes intentarlo de nuevo.`
          };

          // Ocultar popup y redirigir
          setTimeout(() => {
            this.resultPopup.show = false;
            this.$router.push('/dashboard');
          }, 3000);
        } else {
          console.warn('⚠️ El backend respondió sin éxito:', response.data);
          alert('Hubo un problema al registrar el resultado.');
        }
      } catch (error) {
        console.error('❌ Error procesando resultado:', error);
        alert('Error al procesar el resultado del juego');
      }
    },
    showCongratulations(isWinner, amount) {
      const message = isWinner 
        ? `¡FELICIDADES! Has ganado ${amount}€`
        : 'Mejor suerte la próxima vez';
      alert(message);
    }
  }
}
</script>

<style scoped>
.waiting-room-section {
  width: 100%;
  min-height: 60vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: transparent;
  margin-top: 32px;
}
.waiting-room-card {
  background: #222;
  color: #fff;
  padding: 32px 24px;
  border-radius: 12px;
  min-width: 320px;
  max-width: 400px;
  box-shadow: 0 4px 24px rgba(0,0,0,0.15);
  text-align: center;
  margin: 0 auto;
}
.game-container {
  width: 100%;
  max-width: 1200px;
  margin: 8% auto 0px auto;
  background: #222;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 4px 24px rgba(0,0,0,0.15);
}
.game-header {
  background: #333;
  color: #fff;
  padding: 16px 24px;
  text-align: center;
}
.game-header h4 {
  margin: 0 0 8px 0;
}
.game-header p {
  margin: 0;
  color: #ccc;
}
.users-list {
  display: flex;
  justify-content: center;
  margin: 16px 0;
}
.user-item {
  background: #444;
  color: #fff;
  border-radius: 6px;
  padding: 8px 12px;
  margin: 0 4px;
  display: flex;
  align-items: center;
  font-size: 14px;
}
.user-item.empty {
  background: #666;
  color: #bbb;
}
button {
  padding: 8px 16px;
  background-color: #28a745;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  margin: 8px 4px 0 4px;
}
button:last-child {
  background-color: #dc3545;
}


/*popup*/
.popup-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
}

.popup-content {
  background-color: white;
  padding: 2rem;
  border-radius: 1rem;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
  max-width: 90%;
  width: 100%;
  max-width: 400px;
  text-align: center;
}

.popup-content h2 {
  color: black;
  font-size: 1.5rem;
  margin-bottom: 1rem;
}

.popup-content p {
  color: black;
  margin-bottom: 0.75rem;
}

.popup-content .note {
  font-size: 0.875rem;
  color: #555;
}

@keyframes popupFadeIn {
  from { transform: scale(0.8); opacity: 0; }
  to { transform: scale(1); opacity: 1; }
}
</style> 